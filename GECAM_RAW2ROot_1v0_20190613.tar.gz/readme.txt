	Gecam_lv1_1v0 user logbook:




1v0.basic function :sort sci-data to 12 different hisogram

.......to be done in 1v1 : sort the sci-data and the pps-data




how to run this :

jump to the current location


step 1.

run: .x Gecam_lv1.cc

step 2.

input the raw data filename

step 3.

run: root filename.root
run:TBrowser b

step 4.

click the filename in the interface 
 
